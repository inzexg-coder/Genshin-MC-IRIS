# TeyvatShader

Форк **Complementary Reimagined r5.8.1** (EminGT) — геншиновский визуал поверх той же базы.
Имя изменено согласно лицензии: без слова «Complementary», отличие > 3 символов.

**Установка:** заархивировать содержимое этой папки в `TeyvatShader.zip`
(архив должен содержать `shaders/` в корне) и положить в `.minecraft/shaderpacks/`.

**Что изменено от оригинала:**
- `gbuffers_terrain.glsl` / `gbuffers_block.glsl` — зеркальное золото: металл
  определяется по labPBR specular-карте (G=metal, R=smoothness) для любых блоков,
  отражения мира как у воды (colortex4.a -> fresnelM в composite1)
- `block.properties` — мраморный набор: 10996, фонарь отдельно 10997 (emission=7)
- `lib/lighting/mainLighting.glsl` — тун-ступени TOON_BANDING + GGX-блики металла
  от фонарей/факелов
- `lib/colors/` — палитра Мондштадта, `common.glsl` — WATERCOLOR/ATM_FOG/дефолты
- `shaders/pack.json` — описание + креды оригинала (требование лицензии 1.3.a)
- `shaders/settings.json` — профиль по умолчанию: `SHADER_STYLE 4` (Unbound, фэнтези-стиль,
  ближе к геншину), остальное — дефолты базы
- `License.txt` — не тронут (требование лицензии 1.3.b)

**Точки правки под геншиновский лук (следующие итерации):**
- `shaders/lib/colors/skyColors.glsl` — палитра неба (день/ночь/закат) под регион
- `shaders/lib/colors/lightAndAmbientColors.glsl` — тон солнца и амбиента
- `shaders/lib/atmospherics/sky.glsl` — градиенты и glare
- `shaders/lib/lighting/` — тун-рамп диффуза (banded lighting)
- `shaders/program/composite1.glsl` — пост-эффекты: контур, цветокоррекция

**Обновление базы:** `scripts/fetch-upstream.sh`, затем `diff -r` против `shader/upstream/`.

**Комплаенс-чеклист (License Agreement 1.6, раздел 1.3):**
- [x] Оригинал указан с ссылкой на complementary.dev
- [x] License.txt внутри без изменений
- [x] Название без «Complementary», отличие > 3 символов
- [x] Лук заметно отличается (день/оверворлд) — гарантируем палитрой и тун-стилем
- [ ] Других лицензий в паке нет (следить при добавлении своих ассетов)

### Журнал изменений

### 2026-08-05 — Отражения золота через specular-карту, фонари светят сильнее
- Золотая окантовка отражает мир независимо от мат-идов: детект металла по
  specular (G) + smoothness (R), `reflectionStrength = 0.98 * goldMix` в colortex4.a.
- Фонарь: отдельный мат-ид 10997, `emission = max(emission, 7.0)`.
- Текстуры v8: античная палитра, резьба, прожилки золота, без ромбов; новые
  top-текстуры `marble_gold_top` / `marble_top` для орнамента на всех гранях.


### 2026-08-03 — Палитра Мондштадта (базовая)
- `shaders/lib/colors/skyColors.glsl`:
  - день: зенит чистая лазурь `(0.97, 1.0, 0.86)`, середина пастельная `(1.42, 1.36, 1.30)`,
    горизонт светлый тёплый `(1.02, 1.0, 0.95)`
  - закат: верх розовее `(0.74, 0.54, 0.50)`, середина `(1.9, 1.36, 1.14)`, низ персик `(1.55, 0.92, 0.6)`
  - ночь: глубокий индиго `vec3(0.06, 0.115, 0.27)`
- `shaders/lib/colors/lightAndAmbientColors.glsl`:
  - день: свет золотистый, чище (меньше оранжевого) `(0.70, 0.60, 0.44) * 2.05`
  - амбиент ярче `* 0.92` (голубое небо), ночь синее `(0.075, 0.11, 0.21)`
  - лучи света (god rays) слегка подстроены `(0.42, 0.72, 1.22)`

Палитра адаптивная: считается от ванильного skyColor биома, поэтому в равнинах,
лесах и лугах даёт мондштадтский оттенок, сохраняя различия биомов.

### 2026-08-03 — Тун-шейдинг (первый проход)
- Включены встроенные контуры: `WORLD_OUTLINE` (светлая кромка) и `DARK_OUTLINE`
  (тёмная линия) — аниме-контур из коробки, толщину/силу можно крутить в Iris UI
  (`WORLD_OUTLINE_THICKNESS`, `WORLD_OUTLINE_I`, `DARK_OUTLINE_THICKNESS`)
- Новый тун-свет: `TOON_BANDING` — солнечный свет ложится 3 ступенями (0/0.5/1)
  с плавными переходами, амбиент и блоковый свет остаются гладкими
  (классический cel-look)
- Новый экран настроек в Iris: `TEYVAT_SETTINGS` — `TOON_BANDING`,
  `TOON_BAND_STEP1`, `TOON_BAND_STEP2`, `TOON_BAND_SOFTNESS`
- Правки: `lib/common.glsl`, `lib/util/commonFunctions.glsl`,
  `lib/lighting/mainLighting.glsl`, `shaders.properties`
